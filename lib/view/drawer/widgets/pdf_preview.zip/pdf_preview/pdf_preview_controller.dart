import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../../data/model/catalog/get_catalog_pdf_model.dart';
import '../../../../data/repositories/home/catalogue_repository.dart';
import '../../../../data/repositories/watchlist/watchlist_repository.dart';
import '../../../../exports.dart';

class PdfPreviewController extends GetxController {
  RxBool isLoader = false.obs;
  RxBool isFromCatalog = true.obs;
  RxString pdfTitle = ''.obs;
  RxString catalogueId = ''.obs;

  RxList<CatalogPdfModel> productList = <CatalogPdfModel>[].obs;
  List<pw.MemoryImage?> productImages = [];

  Rx<Uint8List>? docPdf = Uint8List(0).obs;

  @override
  void onInit() {
    super.onInit();
    if (Get.arguments != null) {
      pdfTitle.value = Get.arguments["title"] ?? "";
      catalogueId.value = Get.arguments["catalogueId"] ?? "";
      isFromCatalog.value = Get.arguments["isFromCatalog"] ?? true;
    }
  }

  @override
  void onReady() async {
    super.onReady();
    await loadDataAndImages();
  }

  Future<void> loadDataAndImages() async {
    isLoader.value = true;

    try {
      if (isFromCatalog.isTrue) {
        await CatalogueRepository.downloadCatalogueAPI(
          loader: isLoader,
          catalogueId: catalogueId.value,
          title: pdfTitle.value,
          catalogueType: CatalogueType.grid,
          onSuccess: () async {
            await preloadImages();
          },
        );
      } else {
        await WatchListRepository.downloadWatchAPI(
          loader: isLoader,
          watchId: catalogueId.value,
          title: pdfTitle.value,
          onSuccess: () async {
            await preloadImages();
          },
        );
      }
    } finally {
      isLoader.value = false;
    }
  }

  Future<void> preloadImages() async {
    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ));

    productImages = [];
    printYellow("🔵 Loading ${productList.length} images...");

    for (final product in productList) {
      final url = product.inventoryImage ?? '';
      if (url.isEmpty) {
        productImages.add(null);
        continue;
      }
      try {
        final response = await dio.get<List<int>>(
          url,
          options: Options(responseType: ResponseType.bytes),
        );
        final bytes = Uint8List.fromList(response.data ?? []);
        productImages.add(pw.MemoryImage(bytes));
        printYellow("✅ Loaded image: $url");
      } catch (e) {
        printYellow("⚠️ Failed image: $url → $e");
        productImages.add(null);
      }
    }

    printYellow("🟢 All images loaded: ${productImages.length}");
  }

  Future<void> downloadPDF({bool isDownload = false}) async {
    Directory appDocDir;
    if (isDownload) {
      if (Platform.isAndroid) {
        appDocDir = Directory("/storage/emulated/0/Download");
      } else {
        appDocDir = await getApplicationDocumentsDirectory();
      }
    } else {
      appDocDir = await getTemporaryDirectory();
    }

    String appDocPath = appDocDir.path;
    Directory catalogueDir = Directory("$appDocPath/pingaksh");

    if (!await catalogueDir.exists()) await catalogueDir.create();

    String filePath = '${catalogueDir.path}/${pdfTitle.value}.pdf';
    File file = File(filePath);
    if (docPdf != null) await file.writeAsBytes(docPdf!.value);

    printYellow('📄 File saved at $filePath');
    if (isDownload) UiUtils.toast("PDF downloaded successfully");
  }
}
