import 'package:flutter/material.dart' as widget;
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart';
import 'package:printing/printing.dart';

import '../../../../data/model/catalog/get_catalog_pdf_model.dart';
import '../../../../exports.dart';
import '../../../../packages/cached_network_image/cached_network_image.dart';
import '../../../../res/app_bar.dart';
import '../../../../utils/device_utils.dart';
import 'pdf_preview_controller.dart';

class PdfPreviewScreen extends widget.StatelessWidget {
  PdfPreviewScreen({super.key});

  final PdfPreviewController con = Get.put(PdfPreviewController());

  @override
  widget.Widget build(widget.BuildContext context) {
    return Obx(
      () => widget.Scaffold(
        backgroundColor: widget.Theme.of(context).colorScheme.surface,
        appBar: MyAppBar(
          title: "${con.pdfTitle.value} PDF Preview",
          actions: [
            if (con.isFromCatalog.isFalse)
              AppIconButton(
                icon: SvgPicture.asset(AppAssets.shareIcon),
                onPressed: () async {
                  if (con.docPdf?.value != null) {
                    await Printing.sharePdf(bytes: con.docPdf!.value, filename: '${con.pdfTitle.value}(Pingaksh).pdf');
                  }
                },
              ),
            (defaultPadding / 2).horizontalSpace,
          ],
        ),
        body: con.isLoader.isFalse
            ? con.isFromCatalog.isTrue
                ? con.productList.isNotEmpty
                    ? widget.SafeArea(
                        child: widget.Padding(
                          padding: widget.EdgeInsets.all(defaultPadding),
                          child: widget.GridView.builder(
                            gridDelegate: widget.SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: DeviceUtil.isTablet(context) ? 4 : 3,
                              crossAxisSpacing: defaultPadding / 2,
                              mainAxisSpacing: defaultPadding / 2,
                              childAspectRatio: 2 / 3.3, // Match PDF aspect ratio
                            ),
                            itemCount: con.productList.length,
                            itemBuilder: (context, index) {
                              final product = con.productList[index];
                              return widget.Container(
                                decoration: widget.BoxDecoration(
                                  border: widget.Border.all(),
                                  borderRadius: widget.BorderRadius.circular(10),
                                ),
                                child: widget.Column(
                                  children: [
                                    widget.Padding(
                                      padding: const widget.EdgeInsets.only(bottom: 3),
                                      child: widget.AspectRatio(
                                        aspectRatio: 1.3,
                                        child: /*product.inventoryImage != null && product.inventoryImage!.isNotEmpty
                                            ?*/
                                            AppNetworkImage(
                                          imageUrl: product.inventoryImage ?? "",
                                          borderRadius: widget.BorderRadius.circular(10),
                                          fit: widget.BoxFit.cover,
                                        ),

                                        /*widget.ClipRRect(
                                                borderRadius: widget.BorderRadius.circular(10),
                                                child: widget.Image.network(
                                                  product.inventoryImage!,
                                                  fit: widget.BoxFit.cover,
                                                  errorBuilder: (context, error, stackTrace) => const widget.Icon(widget.Icons.broken_image),
                                                ),
                                              )*/
                                        /*  : widget.Container(
                                                alignment: widget.Alignment.center,
                                                child: SvgPicture.asset(AppAssets.placeHolderImage, fit: widget.BoxFit.cover),
                                              ),*/
                                      ),
                                    ),
                                    widget.Padding(
                                      padding: const widget.EdgeInsets.symmetric(horizontal: 8),
                                      child: widget.Column(
                                        children: [
                                          widget.SizedBox(height: defaultPadding),
                                          widget.Text(
                                            product.name ?? '',
                                            style: const widget.TextStyle(
                                              fontSize: 10,
                                              fontWeight: widget.FontWeight.bold,
                                            ),
                                            /* widget.Theme.of(context).textTheme.bodyMedium?.copyWith(
                                              fontWeight: widget.FontWeight.bold,
                                              fontSize: 10,
                                            ),*/
                                            textAlign: widget.TextAlign.center,
                                            maxLines: 2,
                                          ),
                                          widget.SizedBox(height: defaultPadding),
                                          //TODO: ADD Collection Name
                                          const widget.Text(
                                            "Collection: -",
                                            style: widget.TextStyle(fontSize: 10),
                                            textAlign: widget.TextAlign.center,
                                          ),
                                          widget.SizedBox(height: defaultPadding),
                                          widget.Text(
                                            "MRP: \t${UiUtils.amountFormat(product.price ?? 0)}",
                                            style: const widget.TextStyle(
                                              fontSize: 10,
                                              color: widget.Color(0xFF993F8A),
                                            ),
                                            textAlign: widget.TextAlign.center,
                                          ),
                                          widget.SizedBox(height: defaultPadding / 2),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      )
                    : const widget.Center(
                        child: widget.Text(
                        "NO ITEM FOUND",
                        style: widget.TextStyle(
                          fontSize: 18,
                          color: AppColors.lightGrey,
                          fontWeight: widget.FontWeight.bold,
                        ),
                      ))
                : Obx(() {
                    if (con.isLoader.isTrue) {
                      return const widget.Center(child: CircularLoader());
                    }

                    if (con.productList.isEmpty) {
                      return const widget.Center(child: widget.Text("No products found"));
                    }

                    if (con.productImages.isNotEmpty) {
                      return const widget.Center(child: CircularLoader());
                    }

                    return PdfPreview(
                      pdfFileName: '${con.pdfTitle.value}(Pingaksh).pdf',
                      allowPrinting: false,
                      canChangeOrientation: false,
                      canChangePageFormat: false,
                      allowSharing: false,
                      build: (format) async {
                        try {
                          // 100% pdf widgets only from here on
                          final pdf = Document();
                          final exportPdf = Document();
                          // define plain font sizes here
                          const double fontSizeMedium = 12.0;
                          const double fontSizeBold = 12.0;
                          // final String primaryHex = AppColors.fromColor(Theme.of(context).primaryColor);
                          final montserratBold = Font.ttf(await rootBundle.load(AppAssets.montserratBold));
                          final montserratMedium = Font.ttf(await rootBundle.load(AppAssets.montserratMedium));

                          final commonMediumStyle = TextStyle(fontSize: fontSizeMedium, font: montserratMedium);
                          final commonBoldText = TextStyle(fontSize: fontSizeBold, font: montserratBold);
                          // final PdfColor primaryColorPw = PdfColor.fromHex(primaryHex);
                          final PdfColor primaryColor = PdfColor.fromHex(AppColors.fromColor(widget.Theme.of(context).primaryColor));
                          // Guard: we must have images ready and list non-empty
                          if (con.productList.isEmpty || con.productImages.isEmpty) {
                            // quick single page saying empty
                            pdf.addPage(
                              Page(
                                pageFormat: format,
                                build: (_) => Center(child: Text('No products/images')),
                              ),
                            );
                            con.docPdf?.value = await pdf.save();
                            return con.docPdf!.value;
                          }

                          // chunk to avoid heavy single page build
                          final chunks = chunkList(con.productList, 48); // 3 cols × 16 rows per page (tweak as you like)
                          for (int i = 0; i < chunks.length; i++) {
                            final products = chunks[i];
                            final images = con.productImages
                                .skip(i * 48)
                                .take(products.length) // ensure same length
                                .toList();

                            final page = buildGridPage(
                              format: format,
                              products: products,
                              images: images,
                              commonBoldText: commonBoldText,
                              commonMediumStyle: commonMediumStyle,
                              primary: primaryColor,
                            );

                            pdf.addPage(page);
                            exportPdf.addPage(page);
                          }

                          final bytes = await exportPdf.save();
                          con.docPdf?.value = bytes;
                          return await pdf.save();
                        } catch (e, st) {
                          // If anything fails, return a small doc so PdfPreview stops spinning
                          widget.debugPrint('PDF build failed: $e\n$st');
                          final fallback = Document()..addPage(Page(build: (_) => Center(child: Text('Failed to build PDF'))));
                          final b = await fallback.save();
                          con.docPdf?.value = b;
                          return b;
                        }
                      },
                    );
                  })
            : widget.Container(),
      ),
    );
  }

  List<List<T>> chunkList<T>(List<T> list, int chunkSize) {
    List<List<T>> chunks = [];
    for (var i = 0; i < list.length; i += chunkSize) {
      chunks.add(
        list.sublist(i, i + chunkSize > list.length ? list.length : i + chunkSize),
      );
    }
    return chunks;
  }
}

MultiPage buildGridPage({
  required PdfPageFormat format,
  required List<CatalogPdfModel> products,
  required List<MemoryImage?> images,
  required TextStyle commonBoldText,
  required TextStyle commonMediumStyle,
  required PdfColor primary,
}) {
  // simple table-like grid: 3 columns with fixed cell size to avoid infinite layout
  const cols = 3;
  final cellWidth = (format.availableWidth - 2 * 8) / cols; // 8 is padding per cell
  const cellHeight = 250.0;

  List<Widget> rows = [];
  for (int i = 0; i < products.length; i += cols) {
    final rowChildren = <Widget>[];

    for (int c = 0; c < cols; c++) {
      final idx = i + c;
      if (idx >= products.length) {
        // empty filler cell to keep layout stable
        rowChildren.add(SizedBox(width: cellWidth, height: cellHeight));
        continue;
      }

      final p = products[idx];
      final img = (idx < images.length) ? images[idx] : null;

      rowChildren.add(
        Container(
          width: cellWidth,
          height: cellHeight,
          decoration: BoxDecoration(border: Border.all(width: 0.5)),
          padding: const EdgeInsets.all(6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // image box
              Container(
                height: 140,
                decoration: BoxDecoration(border: Border.all(width: 0.3)),
                child: (img != null) ? Image(img, fit: BoxFit.cover) : Center(child: Text('No Image', style: commonMediumStyle)),
              ),
              SizedBox(height: 6),
              Text(p.name ?? '-', style: commonBoldText, maxLines: 1, textAlign: TextAlign.center),
              SizedBox(height: 2),
              Text('Metal: ${p.metal ?? '-'}', style: commonMediumStyle, textAlign: TextAlign.center),
              SizedBox(height: 2),
              Text('Clarity: ${p.diamondClarity ?? '-'}', style: commonMediumStyle, textAlign: TextAlign.center),
              SizedBox(height: 2),
              Text(
                'MRP: ₹${(p.price ?? 0).toStringAsFixed(0)}',
                style: commonMediumStyle.copyWith(color: primary),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    rows.add(Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: rowChildren,
    ));

    rows.add(SizedBox(height: 8));
  }

  return MultiPage(
    pageFormat: format,
    margin: const EdgeInsets.all(16),
    build: (_) => rows,
  );
}

MultiPage multiPage({
  required PdfPageFormat format,
  required PdfColor primaryColor,
  required Font montserratBold,
  required Font montserratMedium,
  required TextStyle commonBoldText,
  required TextStyle commonMediumStyle,
  List<MemoryImage?>? productImages,
  required List<CatalogPdfModel> productList,
  bool isListView = false,
}) {
  return MultiPage(
    maxPages: 999, // allow many pages safely
    pageTheme: PageTheme(
      margin: const EdgeInsets.symmetric(horizontal: 1 * PdfPageFormat.cm, vertical: 0.5 * PdfPageFormat.cm).copyWith(top: defaultPadding),
      textDirection: TextDirection.ltr,
      orientation: PageOrientation.portrait,
      pageFormat: format.copyWith(
        marginBottom: 0,
        marginLeft: 40,
        marginRight: 40,
        marginTop: 0,
      ),
    ),
    build: (context) => [
      isListView
          ? Column(
              children: List.generate(
                productList.length,
                (index) {
                  final img = (productImages != null && index < productImages.length) ? productImages[index] : null;
                  return Padding(
                    padding: EdgeInsets.only(bottom: defaultPadding),
                    child: Container(
                      height: 200,
                      decoration: BoxDecoration(
                        border: Border.all(),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          AspectRatio(
                            aspectRatio: 1.1,
                            child: img != null
                                ? Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      image: DecorationImage(fit: BoxFit.cover, image: img),
                                    ),
                                  )
                                : SvgImage(svg: AppAssets.placeHolderImage, fit: BoxFit.cover),
                          ),
                          SizedBox(width: defaultPadding),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("${productList[index].name}", style: commonBoldText, textAlign: TextAlign.center),
                                SizedBox(height: defaultPadding / 2),
                                Text("Collection: -", style: commonMediumStyle, textAlign: TextAlign.center),
                                SizedBox(height: defaultPadding / 2),
                                Text("MRP: ${productList[index].price}", style: commonMediumStyle.copyWith(color: PdfColor.fromHex("#993F8A")), textAlign: TextAlign.center),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            )
          : Wrap(
              spacing: defaultPadding,
              runSpacing: defaultPadding,
              children: List.generate(
                productList.length,
                (index) {
                  final img = (productImages != null && index < productImages.length) ? productImages[index] : null;
                  return Container(
                    width: (format.availableWidth - (2 * defaultPadding)) / 3,
                    decoration: BoxDecoration(
                      border: Border.all(),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        AspectRatio(
                          aspectRatio: 1.3,
                          child: img != null
                              ? Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: DecorationImage(fit: BoxFit.cover, image: img),
                                  ),
                                )
                              : SvgImage(svg: AppAssets.placeHolderImage, fit: BoxFit.cover),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: Column(
                            children: [
                              SizedBox(height: defaultPadding),
                              Text("${productList[index].name}", style: commonBoldText, textAlign: TextAlign.center, maxLines: 2),
                              SizedBox(height: defaultPadding),
                              Text("Collection: -", style: commonMediumStyle, textAlign: TextAlign.center),
                              SizedBox(height: defaultPadding),
                              Text("MRP: ${productList[index].price}", style: commonMediumStyle.copyWith(color: PdfColor.fromHex("#993F8A")), textAlign: TextAlign.center),
                              SizedBox(height: defaultPadding / 2),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    ],
  );
}
